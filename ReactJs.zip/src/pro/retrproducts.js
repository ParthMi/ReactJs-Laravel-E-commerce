// import React, { useEffect,useState } from 'react'
// import Products from './Products';
// import "./style.css";

// const RetrProduct = () => {

//     const [productsData,setProductsData]=useState([]);
//     const Product=()=>{
//         fetch("http://localhost:8000/api/products")
//         .then((response)=>response.json())
//         .then((json)=>{
//             console.log(json);
//             setProductsData(json);
//         });
//     };
//     useEffect(() => {
//        Product()
//       }, []);
      
//     return(<>
//         <Products productsData={productsData} />
//        </>
//     )
// }

// export default RetrProduct

