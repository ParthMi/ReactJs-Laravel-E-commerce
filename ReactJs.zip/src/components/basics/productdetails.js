import React from 'react'

const Productdetails = () => {
  return (
    <div>
      hello
    </div>
  )
}

export default Productdetails
