// const Product=[{
//     id:1,
//     image:"https://media.croma.com/image/upload/v1662703724/Croma%20Assets/Communication/Mobiles/Images/261934_qgssvy.png",
//     name:"I phone 14 pro",
//     price:"1,00,000",
//     category:"mobile",
//     desc:"apple"
// },
// {
//     id:2,
//     image:"https://media.croma.com/image/upload/v1675229552/Croma%20Assets/Communication/Mobiles/Images/268427_lfgpmq.png",
//     name:"oppo reno 8t 5G",
//     price:"30,000",
//     category:"mobile",
//     desc:"oppo"
// },{
//     id:3,
//     image:"https://cdn.shopify.com/s/files/1/0057/8938/4802/products/back_4b76a852-bc9e-4196-b901-bc102ea6b447_600x.png?v=1658534328",
//     name:"boat 148",
//     price:"1,000",
//     category:"buds",
//     desc:"boAt"
// },{
//     id:4,
//     image:"https://m.media-amazon.com/images/I/61czoakRo1L._SX425_.jpg",
//     name:"Cabel",
//     price:"400",
//     category:"accessories",
//     desc:"Charger"
// },{
//     id:5,
//     image:"https://cdn.90mobiles.com/dataup/2022/09/noise-colorfit-pulse-2-max-smartwatch.png",
//     name:"Boat smart watch Warrior",
//     price:"3,000",
//     category:"watch",
//     desc:"smart watch"
// },{
//     id:6,
//     image:"https://cdn.shopify.com/s/files/1/0137/0292/2286/products/epic-plus-black_1_400x.png?v=1671192278",
//     name:"Epic Plus",
//     price:"1,200",
//     category:"watch",
//     desc:"smart watch"
// }]

// export default Product


// const Product =  async() => {
//     const response = await fetch('http://localhost:8000/api/products');
//     const json = await response.json();
//     return json;
// }


// const Product=[{"pid":2,"product_name":"i phone 14 pro","product_img":"https:\/\/m.media-amazon.com\/images\/W\/IMAGERENDERING_521856-T1\/images\/I\/71yzJoE7WlL._SX522_.jpg","product_price":"i phone 14 pro","product_description":"i phone 14 pro","created_at":"2023-03-24T16:23:35.000000Z","updated_at":"2023-03-24T16:23:35.000000Z"},{"pid":3,"product_name":"Oppo reno 8t 5g","product_img":"https:\/\/media.croma.com\/image\/upload\/v1675229552\/Croma%20Assets\/Communication\/Mobiles\/Images\/268427_lfgpmq.png","product_price":"Oppo reno 8t 5g","product_description":"Oppo reno 8t 5g","created_at":"2023-03-24T16:25:34.000000Z","updated_at":"2023-03-24T16:25:34.000000Z"}]

// export default Product
    

